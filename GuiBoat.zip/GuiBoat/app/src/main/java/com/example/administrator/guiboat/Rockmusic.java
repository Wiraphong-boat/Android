package com.example.administrator.guiboat;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Rockmusic extends AppCompatActivity {
    MediaPlayer myaudio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rockmusic);

    }

    public void play(View view) {
        myaudio = MediaPlayer.create(this,R.raw.shadow);
        myaudio.start();
    }

    public void stop(View view) {
        myaudio.stop();
        myaudio = null;
    }
}

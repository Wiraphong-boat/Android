package com.example.administrator.guiboat;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Listen extends AppCompatActivity {
     MediaPlayer mySoude;

     int paused;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen);
    }


    public void play(View view) {
        mySoude = MediaPlayer.create(this,R.raw.dia);
        mySoude.start();
    }

    public void stop(View view) {
        mySoude.stop();
        mySoude = null;
    }
}
